# ComicCraft — AI Comic Story Creator

ComicCraft is a FastAPI web application based on the supplied project document. It accepts a story prompt, character, setting, tone and art style, generates a five-panel outline and story with Gemini, generates panel images through Hugging Face or local Diffusers, renders a Jinja2 preview and exports a PDF.

## Architecture

Browser → FastAPI/Jinja2 → Gemini outline → Gemini story → image provider → layout builder → FPDF export.

## Quick start — Windows

1. Install Python 3.11 or newer.
2. Open this folder in VS Code.
3. Open Terminal → New Terminal.
4. Create the environment:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

5. Install:

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

6. Copy `.env.example` to `.env`.
7. Add your `GEMINI_API_KEY`.
8. For image generation choose:
   - `IMAGE_PROVIDER=hf` + `HF_API_KEY` for hosted image inference, or
   - `IMAGE_PROVIDER=diffusers` for local generation (a suitable GPU is strongly recommended), or
   - `IMAGE_PROVIDER=placeholder` for an end-to-end UI/PDF test without image AI.

9. Run:

```powershell
uvicorn app.main:app --reload
```

10. Open:
   - http://127.0.0.1:8000
   - http://127.0.0.1:8000/docs

## API test

POST `/generate-comic/json`:

```json
{
  "story_prompt": "A brave fox explores an enchanted forest and discovers a hidden moon garden.",
  "character_name": "Milo",
  "setting": "Enchanted forest",
  "tone": "Funny",
  "art_style": "Comic book"
}
```

## Notes

The supplied documentation names Gemini 1.5 Flash/Pro and Stable Diffusion v1.5. Those are reflected in the architecture, but the implementation uses the current Google GenAI SDK and configurable model names so the application does not depend on the retired/changed SDK patterns in the older document.

The image provider has a safe placeholder fallback so a missing/failed image service does not crash the entire comic workflow. For production, remove that fallback and fail fast if strict AI-only generation is required.
