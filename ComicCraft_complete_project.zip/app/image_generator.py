from pathlib import Path
import re
import uuid

from PIL import Image, ImageDraw, ImageFont

from app.config import settings

def _safe_name(value: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9_-]+", "-", value).strip("-")
    return value[:50] or "panel"

def _placeholder(prompt: str, panel_number: int, output: Path):
    # Reliable no-key fallback so the application can always be tested end-to-end.
    img = Image.new("RGB", (1024, 768), "white")
    draw = ImageDraw.Draw(img)
    title = f"ComicCraft - Panel {panel_number}"
    draw.rectangle((20, 20, 1004, 748), outline="black", width=8)
    draw.text((50, 55), title, fill="black")
    words = prompt[:600]
    draw.multiline_text((55, 150), words, fill="black", spacing=12)
    draw.text((55, 690), "Demo image. Configure HF_API_KEY or IMAGE_PROVIDER=diffusers for AI art.",
              fill="black")
    img.save(output, "PNG")

def _hf_image(prompt: str, output: Path):
    from huggingface_hub import InferenceClient
    if not settings.hf_api_key:
        raise RuntimeError("HF_API_KEY is required for IMAGE_PROVIDER=hf.")
    client = InferenceClient(provider="hf-inference", api_key=settings.hf_api_key)
    image = client.text_to_image(prompt, model=settings.image_model)
    image.save(output)

def _diffusers_image(prompt: str, output: Path):
    import torch
    from diffusers import StableDiffusionPipeline
    pipe = StableDiffusionPipeline.from_pretrained(
        settings.image_model,
        torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
    )
    device = "cuda" if settings.use_gpu and torch.cuda.is_available() else "cpu"
    pipe = pipe.to(device)
    image = pipe(
        prompt,
        num_inference_steps=25,
        guidance_scale=7.0,
    ).images[0]
    image.save(output)

def generate_image(prompt: str, panel_number: int, art_style: str) -> str:
    filename = f"{_safe_name(art_style)}-{panel_number}-{uuid.uuid4().hex[:8]}.png"
    output = Path(settings.output_dir) / filename
    full_prompt = (
        f"{prompt}, {art_style} comic illustration, clean composition, expressive characters, "
        "consistent character design, cinematic lighting, no watermark, no text"
    )
    try:
        if settings.image_provider.lower() == "hf":
            _hf_image(full_prompt, output)
        elif settings.image_provider.lower() == "diffusers":
            _diffusers_image(full_prompt, output)
        else:
            _placeholder(full_prompt, panel_number, output)
    except Exception:
        # Preserve end-to-end application reliability; the UI still explains the fallback.
        _placeholder(full_prompt, panel_number, output)
    return f"/static/panels/{filename}"
