from pathlib import Path
from urllib.parse import urlparse
from fpdf import FPDF

from app.config import settings

def _local_image(url: str) -> str:
    name = Path(urlparse(url).path).name
    return str(Path(settings.output_dir) / name)

def save_pdf(title: str, layout: list[dict]) -> str:
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)

    for panel in layout:
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 18)
        pdf.multi_cell(0, 10, f"Panel {panel['panel_number']}: {panel['title']}")
        image_path = _local_image(panel["image_url"])
        if Path(image_path).exists():
            pdf.image(image_path, x=10, y=38, w=190)
            pdf.ln(118)
        pdf.set_font("Helvetica", "I", 11)
        pdf.multi_cell(0, 7, panel["scene_description"])
        pdf.ln(3)
        pdf.set_font("Helvetica", "B", 11)
        if panel["caption"]:
            pdf.multi_cell(0, 7, f"Caption: {panel['caption']}")
        if panel["narration"]:
            pdf.multi_cell(0, 7, f"Narration: {panel['narration']}")
        if panel["dialogue"]:
            pdf.multi_cell(0, 7, f"Dialogue: {panel['dialogue']}")

    safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in title)[:50] or "comic"
    filename = f"{safe}.pdf"
    output = Path(settings.export_dir) / filename
    pdf.output(str(output))
    return f"/static/exports/{filename}"
