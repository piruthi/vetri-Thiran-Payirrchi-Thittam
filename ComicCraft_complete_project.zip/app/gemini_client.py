import json
import re
from google import genai
from google.genai import types

from app.config import settings

def _client():
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured. Add it to .env.")
    return genai.Client(api_key=settings.gemini_api_key)

def _json_from_text(text: str):
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
    text = re.sub(r"\s*```$", "", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}|\[.*\]", text, re.S)
        if not match:
            raise ValueError("Gemini did not return valid JSON.")
        return json.loads(match.group(0))

def generate_outline(req) -> dict:
    client = _client()
    prompt = f"""
Create a cohesive 5-panel comic outline.

User story: {req.story_prompt}
Main character: {req.character_name}
Setting: {req.setting}
Tone: {req.tone}
Art style: {req.art_style}

Return ONLY valid JSON in this exact shape:
{{
  "title": "short comic title",
  "panels": [
    {{
      "panel_number": 1,
      "title": "short panel title",
      "scene_description": "2-3 sentence visual scene description",
      "image_prompt": "detailed image-generation prompt; describe character appearance consistently"
    }}
  ]
}}

Exactly 5 panels. Keep the same main character appearance across all image prompts.
"""
    response = client.models.generate_content(
        model=settings.gemini_outline_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            temperature=0.8,
            response_mime_type="application/json",
        ),
    )
    data = _json_from_text(response.text)
    if len(data.get("panels", [])) != 5:
        raise ValueError("Gemini returned an outline with fewer/more than 5 panels.")
    return data

def generate_story(req, outline: dict) -> dict:
    client = _client()
    prompt = f"""
Write the narration and dialogue for this 5-panel comic.

Story requirements:
- Character: {req.character_name}
- Setting: {req.setting}
- Tone: {req.tone}
- Art style: {req.art_style}
- Original prompt: {req.story_prompt}

Outline:
{json.dumps(outline, ensure_ascii=False)}

Return ONLY valid JSON:
{{
  "panels": [
    {{
      "panel_number": 1,
      "caption": "short ambient caption",
      "narration": "short narrator text",
      "dialogue": "short spoken dialogue"
    }}
  ]
}}

Exactly 5 panel objects. Keep dialogue concise enough to fit a comic page.
"""
    response = client.models.generate_content(
        model=settings.gemini_story_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            temperature=0.9,
            response_mime_type="application/json",
        ),
    )
    return _json_from_text(response.text)
