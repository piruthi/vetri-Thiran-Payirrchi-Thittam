from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent

class Settings(BaseSettings):
    gemini_api_key: str = ""
    gemini_outline_model: str = "gemini-2.5-flash"
    gemini_story_model: str = "gemini-2.5-flash"
    hf_api_key: str = ""
    image_provider: str = "hf"  # hf | diffusers | placeholder
    image_model: str = "stabilityai/stable-diffusion-xl-base-1.0"
    use_gpu: bool = True
    output_dir: Path = BASE_DIR / "static" / "panels"
    export_dir: Path = BASE_DIR / "static" / "exports"
    max_panels: int = 5

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

settings = Settings()
settings.output_dir.mkdir(parents=True, exist_ok=True)
settings.export_dir.mkdir(parents=True, exist_ok=True)
