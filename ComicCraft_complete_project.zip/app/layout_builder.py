def build_comic_layout(outline: dict, story: dict, image_urls: list[str]) -> list[dict]:
    story_by_number = {
        p["panel_number"]: p for p in story.get("panels", [])
    }
    layout = []
    for panel in outline["panels"]:
        number = panel["panel_number"]
        extra = story_by_number.get(number, {})
        layout.append({
            "panel_number": number,
            "title": panel["title"],
            "scene_description": panel["scene_description"],
            "image_prompt": panel["image_prompt"],
            "caption": extra.get("caption", ""),
            "narration": extra.get("narration", ""),
            "dialogue": extra.get("dialogue", ""),
            "image_url": image_urls[number - 1],
        })
    return layout
