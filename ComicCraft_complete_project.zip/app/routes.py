from fastapi import APIRouter, Form, Request, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from app.config import settings
from app.schemas import PromptRequest
from app.gemini_client import generate_outline, generate_story
from app.image_generator import generate_image
from app.layout_builder import build_comic_layout
from app.exporters import save_pdf

router = APIRouter()
templates = Jinja2Templates(directory="templates")

@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

def _generate(req: PromptRequest):
    outline = generate_outline(req)
    story = generate_story(req, outline)
    images = [
        generate_image(p["image_prompt"], p["panel_number"], req.art_style)
        for p in outline["panels"]
    ]
    layout = build_comic_layout(outline, story, images)
    pdf_url = save_pdf(outline["title"], layout)
    return outline["title"], layout, pdf_url

@router.post("/generate", response_class=HTMLResponse)
async def generate(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
):
    try:
        req = PromptRequest(
            story_prompt=story_prompt,
            character_name=character_name,
            setting=setting,
            tone=tone,
            art_style=art_style,
        )
        title, layout, pdf_url = _generate(req)
        return templates.TemplateResponse(
            "comic_preview.html",
            {"request": request, "title": title, "layout": layout, "pdf_url": pdf_url},
        )
    except Exception as exc:
        return templates.TemplateResponse(
            "index.html",
            {"request": request, "error": str(exc)},
            status_code=500,
        )

@router.post("/generate-comic/json")
async def generate_json(payload: PromptRequest):
    try:
        title, layout, pdf_url = _generate(payload)
        return {"title": title, "panels": layout, "pdf_url": pdf_url}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))

@router.post("/test-image")
async def test_image(prompt: str = Form(...), art_style: str = Form("comic book")):
    try:
        url = generate_image(prompt, 1, art_style)
        return {"image_url": url}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))

@router.get("/export-success", response_class=HTMLResponse)
async def export_success(request: Request, pdf_url: str = "/"):
    return templates.TemplateResponse(
        "export_success.html",
        {"request": request, "pdf_url": pdf_url},
    )
